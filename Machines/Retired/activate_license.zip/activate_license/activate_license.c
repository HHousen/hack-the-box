#include <arpa/inet.h>
#include <errno.h>
#include <inttypes.h>
#include <signal.h>
#include <sqlite3.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

void error(const char *msg) {
    fprintf(stderr, "Error: %s", msg);
    exit(1);
}

/** write license into the database so that we know it has been activated */
void activate_license(int sockfd) {
    char buffer[512];

    uint32_t msglen; // our "protocol"/convention: prefix messages with their length
    if (read(sockfd, &msglen, sizeof(msglen)) == -1)
        error(strerror(errno));
    msglen = ntohl(msglen);
    printf("[+] reading %d bytes\n", msglen);

    if (read(sockfd, &buffer, msglen) == -1)
        error(strerror(errno));

    sqlite3 *db;
    sqlite3_stmt *stmt;

    if (sqlite3_open("license.sqlite", &db) != SQLITE_OK)
        error(sqlite3_errmsg(db));
    sqlite3_busy_timeout(db, 2000);

    if (sqlite3_exec(db,
                "CREATE TABLE IF NOT EXISTS license ("
                "   id INTEGER PRIMARY KEY AUTOINCREMENT,"
                "   license_key TEXT"
                ")", NULL, NULL, NULL) != SQLITE_OK)
        error(sqlite3_errmsg(db));

    if (sqlite3_prepare_v2(db, "INSERT INTO license (license_key) VALUES (?)",
            -1, &stmt, NULL) != SQLITE_OK)
        error(sqlite3_errmsg(db));

    if (sqlite3_bind_text(stmt, 1, buffer, sizeof(buffer), NULL) != SQLITE_OK)
        error(sqlite3_errmsg(db));

    if (sqlite3_step(stmt) != SQLITE_DONE)
        error(sqlite3_errmsg(db));

    if (sqlite3_reset(stmt) != SQLITE_OK)
        error(sqlite3_errmsg(db));

    if (sqlite3_finalize(stmt) != SQLITE_OK)
        error(sqlite3_errmsg(db));

    if (sqlite3_close(db) != SQLITE_OK)
        error(sqlite3_errmsg(db));

    printf("[+] activated license: %s\n", buffer);
}

int main(int argc, char** argv) {
    if (argc != 2)
        error("specify port to bind to");

    uint16_t port;
    if (sscanf(argv[1], "%" SCNu16, &port) == -1)
        error(strerror(errno));

    printf("[+] starting server listening on port %d\n", port);

    struct sockaddr_in server;
    server.sin_family       = AF_INET;
    server.sin_addr.s_addr  = htonl(INADDR_LOOPBACK);
    server.sin_port         = htons(port);

    int serverfd;
    if ((serverfd = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)) == -1)
        error(strerror(errno));

    if (bind(serverfd, (struct sockaddr*) &server, sizeof(server)) == -1)
        error(strerror(errno));

    if (listen(serverfd, 100) == -1)
        error(strerror(errno));

    printf("[+] listening ...\n");

    int clientfd;
    socklen_t clientaddrlen;
    struct sockaddr_in clientaddr;
    while (1) {
        if ((clientfd = accept(serverfd, (struct sockaddr *) &clientaddr,
                        &clientaddrlen)) == -1) {
            fprintf(stderr, "Error: accepting client\n");
            continue;
        }

        char clientaddr_s[INET_ADDRSTRLEN];
        inet_ntop(AF_INET, &clientaddr.sin_addr, clientaddr_s, INET_ADDRSTRLEN);
        printf("[+] accepted client connection from %s:%d\n",
                clientaddr_s, clientaddr.sin_port);

        if (!fork()) {
            close(serverfd);

            activate_license(clientfd);

            exit(0);
        }

        signal(SIGCHLD,SIG_IGN);
        close(clientfd);
    }

    return 0;
}
